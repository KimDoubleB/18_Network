
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Kim B b
 */
public class Database {

   private Connection con;
   public Database() {
      con = null;
      try {
         Class.forName("com.mysql.jdbc.Driver");
         String url = "jdbc:mysql://localhost/network";
         String user = "root", passwd = "12345";
         con = (Connection) DriverManager.getConnection(url, user, passwd);
         System.out.println(con);
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }

   }

   public void FinishDB() {
      try {
         if (con != null && !con.isClosed())
            con.close();
      } catch (SQLException e) {
         e.printStackTrace();
      }

   }

   public boolean login(String ID, String PW) {
      Statement stmt = null;
      ResultSet rs = null;
      String id = "";

      try {
         stmt = con.createStatement();
         String sql = "select id from person where id = '" + ID + "' and password = '" + PW + "'";
         rs = stmt.executeQuery(sql);

         while (rs.next()) {
            id = rs.getString(1);
         }
      } catch (SQLException e) {
         e.printStackTrace();
         System.out.println(id + " 11111111 is denied.");
      }
      // ���߿� �̰� statement ������ �� ��������ȭ ���Ѽ� FinishDB���� �� close���� ��.
      if (id.isEmpty()) {
         return false;
         // System.out.println(id +" 222222222 is denied.");
      }

      return true;
   }

   public boolean Signup(String id, String password, String name) {
      try {
         PreparedStatement ps = con.prepareStatement("insert into person value (?,?,?)");
         ps.setString(1, id);
         ps.setString(2, password);
         ps.setString(3, name);

         ps.executeUpdate();
      } catch (Exception ex) {
         ex.printStackTrace();
         return false;
      }
      return true;
   }
   
   public ArrayList<String> ProjectDB(String ID) {
      
      Statement stmt = null;
      ResultSet rs = null;
      ArrayList<String> result = new ArrayList<String>();
      
      
      try {
         stmt = con.createStatement();
         String sql = "select pro_name,role,date from pp natural join project where id = '" + ID + "'";
         rs = stmt.executeQuery(sql);

         while (rs.next()) {
            result.add(new String(rs.getString(1) + "/" + rs.getString(2) + "/" +rs.getString(3)));
         }
         
         
      } catch (SQLException e) {
         e.printStackTrace();
      }

      return result;
      
   }
   
   //������Ʈ�̸��� ���������� ���� project DB ��  pnum �Ӽ��� �������� ���Ƿ� �����ϰ� ����
   public String InsertProject(String p_name, String date) {
      String p_num = "";
      try {
         PreparedStatement ps = con.prepareStatement("insert into project value (?,?,?,?)");
         Random rand = new Random();
         p_num=""+rand.nextInt(10000);
         ps.setString(1, p_num);
         ps.setString(2, p_name);
         ps.setString(3, date);
         ps.setString(4, "");

         ps.executeUpdate();
      } catch (Exception ex) {
         ex.printStackTrace();
      }
      return p_num;
   }
   
   //���� �Լ����� ���� pnum�� ���� pp DB �ϼ�
   public boolean InsertPP(ArrayList<String> id_role, String p_num) {
      try {
         PreparedStatement ps = con.prepareStatement("insert into pp value (?,?,?,?,?,?)");
      
         for(int i=0;i<id_role.size();i++) {
        	 String line=id_role.get(i);
        	 int var = line.indexOf(" ");
        	 String id = line.substring(0, var);
           	 int var2 = line.indexOf("]");
           	 String role = line.substring(var+2, var2);
          	 System.out.println(id + " "+ role);
        	 ps.setString(1, id);
             ps.setString(2, p_num);
             ps.setString(3, role);
             ps.setInt(4, 0);
             ps.setInt(5, 0);
             ps.setInt(6, 0);

             ps.executeUpdate();
         }
         

      } catch (Exception ex) {
         ex.printStackTrace();
         return false;
      }
      return true;
   }
   
   
   public ArrayList<String> IDlist() {
      
      Statement stmt = null;
      ResultSet rs = null;
      ArrayList<String> result = new ArrayList<String>();
      
      
      try {
         stmt = con.createStatement();
         String sql = "select id from person";
         rs = stmt.executeQuery(sql);

         while (rs.next()) {
            result.add(new String(rs.getString(1)));
         }
         
         
      } catch (SQLException e) {
         e.printStackTrace();
      }

      return result;
      
   }
   
   public boolean IDcheck(String ID) {
      Statement stmt = null;
      ResultSet rs = null;
      String id = "";

      try {
         stmt = con.createStatement();
         String sql = "select id from person where id = '" + ID + "'";
         rs = stmt.executeQuery(sql);

         while (rs.next()) {
            id = rs.getString(1);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }
      if (id.isEmpty()) {
         return false;
      }
      
      return true;
   }
}